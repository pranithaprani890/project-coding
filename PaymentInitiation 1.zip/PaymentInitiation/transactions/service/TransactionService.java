package com.scb.PaymentInitiation.transactions.service;

import com.scb.PaymentInitiation.createpayroll.repository.PayrollBatchRepository;
import com.scb.PaymentInitiation.transactions.model.Transaction;
import com.scb.PaymentInitiation.transactions.repository.TransactionRepository;
import com.scb.PaymentInitiation.createpayroll.model.PayrollBatch;
import com.scb.PaymentInitiation.createpayroll.model.Payment;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class TransactionService {
    private final TransactionRepository txnRepo;
    private final PayrollBatchRepository batchRepo;

    public TransactionService(TransactionRepository txnRepo, PayrollBatchRepository batchRepo) {
        this.txnRepo=txnRepo;
        this.batchRepo=batchRepo;
    }

    public List<Transaction> generateFromBatch(Long batchId) {
        PayrollBatch batch = batchRepo.findById(batchId)
                .orElseThrow(() -> new RuntimeException("Batch not found"));


            if (!"Approved".equalsIgnoreCase(batch.getStatus())) {
                throw new RuntimeException("Batch must be approved before generating transactions.");
            }

        List<Transaction> txns = new ArrayList<>();
        for (Payment p : batch.getPayments()) {
            Transaction txn = new Transaction();
            txn.setBatchId(batchId);
            txn.setPayeeRole(p.getPayeeRole());
            txn.setPayeeName(p.getPayeeName());
            txn.setAccountNumber(p.getAccountNumber());
            txn.setAmount(p.getAmount());
            txn.setReference(p.getReference());
            txn.setStatus("SUCCESS");
            txn.setCreatedAt(String.valueOf(LocalDateTime.now()));
            txn.setUpdatedAt(String.valueOf(LocalDateTime.now()));
            txns.add(txnRepo.save(txn));
        }
        return txns;
    }

    public List<Transaction> getAllTransactions() {
        return txnRepo.findAll();
    }

    public List<Transaction> getTransactionsByBatch(Long batchId) {
        return txnRepo.findByBatchId(batchId);
    }

//    public long countTransactionsByBatch(long batchId) {
//        return txnRepo.countByBatchId(batchId);
//    }
}

