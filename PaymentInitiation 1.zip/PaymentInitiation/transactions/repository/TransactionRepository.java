package com.scb.PaymentInitiation.transactions.repository;

import com.scb.PaymentInitiation.transactions.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByBatchId(Long BatchId);
//    List<Transaction> findByAccountNumber(String accountNumber);

//    long countByBatchId(long batchId);
}
