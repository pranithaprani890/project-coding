package com.scb.PaymentInitiation.transactions.controller;

import com.scb.PaymentInitiation.transactions.model.Transaction;
import com.scb.PaymentInitiation.transactions.service.TransactionService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@CrossOrigin(origins = "http://localhost:3000")
public class TransactionController {
    private final TransactionService service;

    public TransactionController(TransactionService service) {
        this.service = service;
    }

    @GetMapping
    public List<Transaction> getAllTransactions() {
        return service.getAllTransactions();
    }

    @PostMapping("/generate/{batchId}")
    public List<Transaction> generateFromBatch(@PathVariable Long batchId) {
        return service.generateFromBatch(batchId);
    }

    @GetMapping("/batch/{batchId}")
    public List<Transaction> getTransactionsByBatch(@PathVariable Long batchId) {
        return service.getTransactionsByBatch(batchId);
    }

//    @GetMapping("/batch/{batchId}/count")
//    public long getTransactionsCountByBatch(@PathVariable Long batchId) {
//        return service.countTransactionsByBatch(batchId);
//    }
}