package com.scb.PaymentInitiation.transactions.model;

import jakarta.persistence.*;
@Entity
@Table(name="transactions")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long batchId;
    private String accountNumber;
    private String payeeName;

    private String payeeRole;
    private String reference;
    private String amount;
    private String status;
    private String createdAt;
    private String updatedAt;


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id=id;
    }

    public Long getBatchId() {
        return batchId;
    }
    public void setBatchId(Long batchId) {
        this.batchId=batchId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber=accountNumber;
    }

    public String getPayeeName() {
        return payeeName;
    }

    public void setPayeeName(String payeeName){
        this.payeeName=payeeName;
    }

    public String getPayeeRole() {
        return payeeRole;
    }

    public void setPayeeRole(String payeeRole) {
        this.payeeRole=payeeRole;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference=reference;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount=amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status=status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt=createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt=updatedAt;
    }
}
