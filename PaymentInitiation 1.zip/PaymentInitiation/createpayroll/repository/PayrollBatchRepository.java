package com.scb.PaymentInitiation.createpayroll.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.scb.PaymentInitiation.createpayroll.model.PayrollBatch;

@Repository
public interface PayrollBatchRepository extends JpaRepository<PayrollBatch, Long> {
}