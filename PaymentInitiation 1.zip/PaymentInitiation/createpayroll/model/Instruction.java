package com.scb.PaymentInitiation.createpayroll.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class Instruction {
    private String paymentCurrency;
    private String debitAccount;
    private String date;

    public String getPaymentCurrency() { return paymentCurrency; }
    public void setPaymentCurrency(String paymentCurrency) { this.paymentCurrency = paymentCurrency; }

    public String getDebitAccount() { return debitAccount; }
    public void setDebitAccount(String debitAccount) { this.debitAccount = debitAccount; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}
