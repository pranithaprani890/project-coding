package com.scb.PaymentInitiation.managepayroll.controller;
import com.scb.PaymentInitiation.createpayroll.repository.PayrollBatchRepository;
import com.scb.PaymentInitiation.createpayroll.model.PayrollBatch;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/manage-payroll")
@CrossOrigin(origins = "http://localhost:3000") // React frontend
public class ManagePayrollController {

    private final PayrollBatchRepository repository;

    public ManagePayrollController(PayrollBatchRepository repository) {
        this.repository = repository;
    }

    // Fetch all batches
    @GetMapping("/batch")
    public List<PayrollBatch> getAllBatches() {
        return repository.findAll();
    }

    // Update batch (submit/edit)
    @PutMapping("/batch/{id}")
    public PayrollBatch updateBatch(@PathVariable Long id, @RequestBody PayrollBatch updated) {
        return repository.findById(id).map(batch -> {
            batch.setStatus(updated.getStatus());
            batch.setUpdatedAt(updated.getUpdatedAt());
            batch.setInstruction(updated.getInstruction());
            batch.setPayments(updated.getPayments());
            return repository.save(batch);
        }).orElseThrow(() -> new RuntimeException("Batch not found"));
    }

    // Delete batch
    @DeleteMapping("/batch/{id}")
    public void deleteBatch(@PathVariable Long id) {
        repository.deleteById(id);
    }
}






