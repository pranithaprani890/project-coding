package com.scb.PaymentInitiation.approvepayroll.repository;

import com.scb.PaymentInitiation.approvepayroll.model.ApprovalLog;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;




public interface ApprovalLogRepository extends JpaRepository<ApprovalLog, Long> {
    List<ApprovalLog> findByBatchId(Long batchId);
}