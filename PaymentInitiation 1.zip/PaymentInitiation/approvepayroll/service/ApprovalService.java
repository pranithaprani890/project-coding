package com.scb.PaymentInitiation.approvepayroll.service;
import com.scb.PaymentInitiation.approvepayroll.model.ApprovalLog;
import com.scb.PaymentInitiation.approvepayroll.repository.ApprovalLogRepository;
import com.scb.PaymentInitiation.createpayroll.model.PayrollBatch;
import com.scb.PaymentInitiation.createpayroll.repository.PayrollBatchRepository;
import com.scb.PaymentInitiation.transactions.service.TransactionService;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;

@Service
public class ApprovalService {

    private final PayrollBatchRepository payrollRepo;
    private final ApprovalLogRepository logRepo;
    private final TransactionService transactionService;

    public ApprovalService(PayrollBatchRepository payrollRepo, ApprovalLogRepository logRepo,
                           TransactionService transactionService) {
        this.payrollRepo = payrollRepo;
        this.logRepo = logRepo;
        this.transactionService=transactionService;
    }

    public ApprovalLog approveOrReject(Long batchId, String action, String remarks, String approvedBy) {
        PayrollBatch batch = payrollRepo.findById(batchId)
                .orElseThrow(() -> new RuntimeException("Batch not found"));

        batch.setStatus(action);
        batch.setUpdatedAt(LocalDateTime.now().toString());
        payrollRepo.save(batch);

        ApprovalLog log = new ApprovalLog();
        log.setBatchId(batchId);
        log.setAction(action);
        log.setRemarks(remarks);
        log.setApprovedBy(approvedBy);
        log.setApprovedAt(LocalDateTime.now());

        ApprovalLog savedlog=logRepo.save(log);

        if("Approved".equalsIgnoreCase(action)) {
            transactionService.generateFromBatch(batchId);
        }

        return savedlog;
    }
}
