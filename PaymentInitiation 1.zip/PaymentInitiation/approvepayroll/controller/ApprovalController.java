package com.scb.PaymentInitiation.approvepayroll.controller;

import com.scb.PaymentInitiation.approvepayroll.model.ApprovalLog;
import com.scb.PaymentInitiation.approvepayroll.service.ApprovalService;
import com.scb.PaymentInitiation.approvepayroll.repository.ApprovalLogRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/approval")
@CrossOrigin(origins = "http://localhost:3000")
public class ApprovalController {

    private final ApprovalService service;
    private final ApprovalLogRepository logRepo;

    public ApprovalController(ApprovalService service, ApprovalLogRepository logRepo) {
        this.service = service;
        this.logRepo = logRepo;
    }

    @PostMapping("/{batchId}")
    public ApprovalLog approveOrReject(
            @PathVariable Long batchId,
            @RequestBody Map<String, String> payload
    ) {
        String action = payload.get("action");
        String remarks = payload.getOrDefault("remarks", "");
        String approvedBy = payload.getOrDefault("approvedBy", "System");

        return service.approveOrReject(batchId, action, remarks, approvedBy);
    }

    @GetMapping("/{batchId}/logs")
    public List<ApprovalLog> getLogs(@PathVariable Long batchId) {
        return logRepo.findByBatchId(batchId);
    }
}
