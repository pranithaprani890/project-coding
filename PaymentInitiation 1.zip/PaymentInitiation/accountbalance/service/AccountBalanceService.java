package com.scb.PaymentInitiation.accountbalance.service;

import com.scb.PaymentInitiation.accountbalance.model.AccountBalance;
import com.scb.PaymentInitiation.accountbalance.model.AccountBalanceEntity;
import com.scb.PaymentInitiation.accountbalance.repository.AccountBalanceRepository;
import com.scb.PaymentInitiation.createpayroll.model.PayrollBatch;
import com.scb.PaymentInitiation.createpayroll.repository.PayrollBatchRepository;
import com.scb.PaymentInitiation.transactions.model.Transaction;
import com.scb.PaymentInitiation.transactions.repository.TransactionRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AccountBalanceService {

    private static final Logger log = LoggerFactory.getLogger(AccountBalanceService.class);
    private final AccountBalanceRepository accRepo;
    private final PayrollBatchRepository batchRepo;
    private final TransactionRepository txnRepo;

    private final BigDecimal DEFAULT_OPENING = new BigDecimal("10000000.00");

    public AccountBalanceService(AccountBalanceRepository accRepo,
                                 PayrollBatchRepository batchRepo,
                                 TransactionRepository txnRepo) {
        this.accRepo = accRepo;
        this.batchRepo = batchRepo;
        this.txnRepo = txnRepo;
    }

    @Transactional(readOnly = true)
    public List<AccountBalance> getBalances() {
        Map<String,String> currencyByAcc = buildCurrencyMap();
        return accRepo.findAll().stream()
                .map(e -> new AccountBalance(
                        e.getAccountNumber(),
                        e.getAccountName(),
                        e.getBalance(),
                        currencyByAcc.getOrDefault(e.getAccountNumber(), "")))
                .collect(Collectors.toList());
    }

    private Map<String,String> buildCurrencyMap() {
        Map<String,String> currencyByAcc = new HashMap<>();
        List<PayrollBatch> batches = batchRepo.findAll();
        // best-effort: first seen currency per account
        for (PayrollBatch b : batches) {
            if (b.getInstruction()!=null && b.getInstruction().getDebitAccount()!=null) {
                String acc = b.getInstruction().getDebitAccount();
                String curr = b.getInstruction().getPaymentCurrency();
                if (!currencyByAcc.containsKey(acc) && curr != null && !curr.isBlank()) {
                    currencyByAcc.put(acc, curr);
                }
            }
        }
        return currencyByAcc;
    }

    @Transactional(readOnly = true)
    public List<Transaction> getTransactionsForAccount(String accountNumber) {
        List<Long> batchIds = batchRepo.findAll().stream()
                .filter(b -> b.getInstruction()!=null && accountNumber.equals(b.getInstruction().getDebitAccount()))
                .map(PayrollBatch::getId)
                .collect(Collectors.toList());

        List<Transaction> out = new ArrayList<>();
        for (Long id : batchIds) out.addAll(txnRepo.findByBatchId(id));

        try {
            out.sort((a,b)->{
                try {
                    String ua = (String) a.getClass().getMethod("getUpdatedAt").invoke(a);
                    String ub = (String) b.getClass().getMethod("getUpdatedAt").invoke(b);
                    if (ua==null) return 1;
                    if (ub==null) return -1;
                    return ub.compareTo(ua);
                } catch(Exception ex){ return 0; }
            });
        } catch(Exception ignored) {}
        return out;
    }

    @Transactional(readOnly = true)
    public List<Transaction> getStatement(String accountNumber, LocalDate from, LocalDate to) {
        List<Transaction> all = getTransactionsForAccount(accountNumber);
        DateTimeFormatter fmt = DateTimeFormatter.ISO_DATE_TIME;
        return all.stream().filter(t -> {
            try {
                String raw = (String) t.getClass().getMethod("getUpdatedAt").invoke(t);
                if (raw == null) return false;
                LocalDateTime ts = LocalDateTime.parse(raw, fmt);
                return (from == null || !ts.toLocalDate().isBefore(from)) &&
                       (to == null || !ts.toLocalDate().isAfter(to));
            } catch (Exception e) {
                return false;
            }
        }).collect(Collectors.toList());
    }

    @Transactional
    public void applyBatchApprovalImpact(Long batchId) {
        PayrollBatch b = batchRepo.findById(batchId).orElse(null);
        if (b == null || b.getInstruction()==null) {
            log.warn("No batch/instruction for id={}", batchId);
            return;
        }

        String debitAcc = b.getInstruction().getDebitAccount();
        if (!StringUtils.hasText(debitAcc)) {
            log.warn("No debit account on batch id={}", batchId);
            return;
        }

        BigDecimal total = BigDecimal.ZERO;
        if (b.getPayments()!=null) {
            for (var p : b.getPayments()) {
                try {
                    BigDecimal amt = new BigDecimal(String.valueOf(p.getAmount()).trim());
                    total = total.add(amt);
                } catch (Exception ex) {
                    log.warn("Skipping non-numeric amount '{}' in batch {}", p.getAmount(), batchId);
                }
            }
        }

        if (total.compareTo(BigDecimal.ZERO) <= 0) {
            log.info("Batch {} total <= 0, nothing to decrement", batchId);
            return;
        }

        int updated = accRepo.decrement(debitAcc, total);
        log.info("Decremented {} by {} (rows updated={})", debitAcc, total, updated);

        if (updated == 0) {
            AccountBalanceEntity e = new AccountBalanceEntity();
            e.setAccountName("Corporate A/C " + debitAcc);
            e.setAccountNumber(debitAcc);
            e.setBalance(DEFAULT_OPENING.subtract(total));
            accRepo.save(e);
            log.info("Created new account row for {} with opening minus total", debitAcc);
        }
    }

    @Transactional
    public void rebuildAccountBalancesFromBatches() {
        List<PayrollBatch> batches = batchRepo.findAll();
        Map<String, BigDecimal> spentPerAcc = new HashMap<>();

        for (PayrollBatch b : batches) {
            if (b.getInstruction() == null) continue;
            String acc = b.getInstruction().getDebitAccount();
            if (acc == null) continue;
            BigDecimal batchSum = BigDecimal.ZERO;
            if (b.getPayments() != null) {
                for (var p : b.getPayments()) {
                    try {
                        batchSum = batchSum.add(new BigDecimal(String.valueOf(p.getAmount())));
                    } catch (Exception ex) {
                        // ignore non-numeric amounts
                    }
                }
            }
            spentPerAcc.merge(acc, batchSum, BigDecimal::add);
        }

        for (Map.Entry<String, BigDecimal> e : spentPerAcc.entrySet()) {
            String acc = e.getKey();
            BigDecimal spent = e.getValue() == null ? BigDecimal.ZERO : e.getValue();
            BigDecimal balance = DEFAULT_OPENING.subtract(spent);

            Optional<AccountBalanceEntity> oe = accRepo.findByAccountNumber(acc);
            if (oe.isPresent()) {
                AccountBalanceEntity ex = oe.get();
                ex.setBalance(balance);
                accRepo.save(ex);
            } else {
                AccountBalanceEntity ne = new AccountBalanceEntity();
                ne.setAccountNumber(acc);
                ne.setAccountName("Corporate A/C " + acc);
                ne.setBalance(balance);
                accRepo.save(ne);
            }
        }
    }

    @Transactional(readOnly = true)
    public List<AccountBalance> getAccountOptions() {
        Map<String, String> currencyByAcc = buildCurrencyMap();
        return accRepo.findAll().stream()
                .map(e -> new AccountBalance(
                        e.getAccountNumber(),
                        e.getAccountName(),
                        e.getBalance(),
                        currencyByAcc.getOrDefault(e.getAccountNumber(), "")))
                .collect(Collectors.toList());
    }
}
