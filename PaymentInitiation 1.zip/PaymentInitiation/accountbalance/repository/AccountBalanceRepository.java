package com.scb.PaymentInitiation.accountbalance.repository;

import com.scb.PaymentInitiation.accountbalance.model.AccountBalanceEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.Optional;

@Repository
public interface AccountBalanceRepository extends JpaRepository<AccountBalanceEntity, Long> {
    Optional<AccountBalanceEntity> findByAccountNumber(String accountNumber);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update AccountBalanceEntity a set a.balance = a.balance - :amount where a.accountNumber = :acc")
    int decrement(@Param("acc") String accountNumber, @Param("amount") BigDecimal amount);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update AccountBalanceEntity a set a.balance = a.balance + :amount where a.accountNumber = :acc")
    int increment(@Param("acc") String accountNumber, @Param("amount") BigDecimal amount);
}
