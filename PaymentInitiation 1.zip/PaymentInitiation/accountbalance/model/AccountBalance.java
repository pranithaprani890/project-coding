package com.scb.PaymentInitiation.accountbalance.model;

import java.math.BigDecimal;

public class AccountBalance {
    private String accountNumber;
    private String accountName;
    private BigDecimal balance;
    private String currency;

    public AccountBalance() {}
    public AccountBalance(String accountNumber, String accountName, BigDecimal balance, String currency) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = balance;
        this.currency = currency;
    }
    public String getAccountNumber() { return accountNumber; }
    public String getAccountName() { return accountName; }
    public java.math.BigDecimal getBalance() { return balance; }
    public String getCurrency() { return currency; }

    public void setAccountNumber(String v) { this.accountNumber = v; }
    public void setAccountName(String v) { this.accountName = v; }
    public void setBalance(java.math.BigDecimal v) { this.balance = v; }
    public void setCurrency(String v) { this.currency = v; }
}
