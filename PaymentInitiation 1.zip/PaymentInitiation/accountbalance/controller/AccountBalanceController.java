package com.scb.PaymentInitiation.accountbalance.controller;

import com.scb.PaymentInitiation.accountbalance.model.AccountBalance;
import com.scb.PaymentInitiation.accountbalance.service.AccountBalanceService;
import com.scb.PaymentInitiation.transactions.model.Transaction;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/account")
@CrossOrigin(origins = "http://localhost:3000")
public class AccountBalanceController {

    private final AccountBalanceService service;

    public AccountBalanceController(AccountBalanceService service) {
        this.service = service;
    }

    @GetMapping("/balance")
    public List<AccountBalance> getBalances() {
        return service.getBalances();
    }

    @GetMapping("/balance/{accountNumber}/transactions")
    public List<Transaction> getTransactions(@PathVariable String accountNumber) {
        return service.getTransactionsForAccount(accountNumber);
    }

    @GetMapping("/balance/{accountNumber}/statement")
    public List<Transaction> getStatement(@PathVariable String accountNumber,
                                          @RequestParam(required = false) String from,
                                          @RequestParam(required = false) String to) {
        LocalDate fromDate = null, toDate = null;
        try {
            if (from != null) fromDate = LocalDate.parse(from);
            if (to != null) toDate = LocalDate.parse(to);
        } catch (Exception ignored) {}
        return service.getStatement(accountNumber, fromDate, toDate);
    }

    @GetMapping("/options")
    public List<AccountBalance> getAccountOptions() {
        return service.getAccountOptions();
    }

    @PostMapping("/rebuild")
    public ResponseEntity<String> rebuildAccounts() {
        service.rebuildAccountBalancesFromBatches();
        return ResponseEntity.ok("Rebuild triggered");
    }
}
